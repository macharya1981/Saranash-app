# ସାରାଂଶ (Saarangsha) — real pipeline + free hosting

A working app: pulls public headlines + teaser text from WSJ, NYT, and FT,
translates them into Odia using **Sarvam AI**, and shows them in an
installable mobile web app (PWA) — for free, no server to maintain.

## Why RSS, not full articles?

WSJ and FT are paywalled — there's no free, legal way to pull their full
article text. What every major paper *does* publish freely is an RSS feed
with the **headline + a short public teaser**. That's what this pipeline
translates. Legal, free, and already a "short read."

---

## Part 1 — Run it locally (you've done this part already)

```bash
pip3 install -r requirements.txt
export SARVAM_API_KEY="your_key_here"
python3 fetch_news.py
python3 -m http.server 8000
```

---

## Part 2 — Host it for free on GitHub Pages, with auto-refresh

This setup means: the news refreshes itself every 6 hours automatically,
and anyone can visit the URL and install it — no server bill, no laptop
needing to stay on.

### Step 1: Create a GitHub repo

1. Go to https://github.com/new
2. Name it e.g. `saarangsha-app`, keep it **Public** (required for free GitHub
   Pages), create it
3. On your Mac, in the project folder:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/saarangsha-app.git
   git push -u origin main
   ```

### Step 2: Add your Sarvam key as a GitHub Secret (never commit it directly)

1. On the repo page: **Settings → Secrets and variables → Actions → New repository secret**
2. Name: `SARVAM_API_KEY`
3. Value: your key
4. Save

### Step 3: Turn on GitHub Pages

1. **Settings → Pages**
2. Source: **Deploy from a branch** → Branch: `main`, folder: `/ (root)`
3. Save — GitHub gives you a URL like:
   `https://YOUR_USERNAME.github.io/saarangsha-app/`

### Step 4: Trigger the first refresh

1. Go to the **Actions** tab in your repo
2. Click **Refresh news** → **Run workflow** (this runs it immediately instead
   of waiting for the 6-hour schedule)
3. Once it finishes (green check), `data.json` in your repo is updated with
   real translated stories, and Pages will serve the new version within a
   minute or two

From now on, this repeats automatically every 6 hours — you don't need to
touch it.

---

## Part 3 — Install it as an app (PWA)

Once the GitHub Pages URL is live:

**On Android (Chrome):** open the URL → tap the **⋮** menu → **Add to Home
screen** / **Install app**.

**On iPhone (Safari):** open the URL → tap the **Share** icon → **Add to
Home Screen**.

It'll appear on the homescreen with its own icon and open full-screen, like
a native app — no App Store or Play Store review needed for this step.

---

## Notes

- **RSS URLs drift.** If a fetch in the Actions log shows 0 entries for a
  feed, the publisher likely moved it — check `RSS_FEEDS` in `fetch_news.py`.
- **Adjust the refresh schedule** by editing the `cron` line in
  `.github/workflows/refresh-news.yml` (currently every 6 hours).
- **Cost**: GitHub Pages + Actions are free for public repos at this scale.
  Sarvam usage is metered — watch your usage on their dashboard.
- **Next step beyond PWA**: wrapping this in Capacitor to actually submit to
  the App Store / Play Store is a separate, bigger project — worth doing
  once you've validated people want to use it.
